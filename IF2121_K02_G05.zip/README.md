# IF2121_K02_G05

# Tugas Besar IF2121 Logika Komputasional
## KIMI NO TUBES
> Sebuah farm simulation role-playing game sebagai seorang programmer yang harus bertani untuk membayar hutangnya dengan menggunakan bahasa pemrograman deklaratif Prolog (gunakan GNU Prolog). Kamu sukses membayar hutangmu jika berhasil mengumpulkan 20000 gold dalam jangka waktu 1 tahun. Ganbatte!

## Daftar Anggota Kelompok
<table>
<tr><td colspan = 3 align = "center">KELOMPOK 5 Terbayang Bayang</td></tr>
<tr><td>No.</td><td>Nama</td><td>NIM</td></tr>
<tr><td>1.</td><td>Wesly Giovano</td><td>13520071</td></tr>
<tr><td>2.</td><td>Lyora Felicya</td><td>13520073</td></tr>
<tr><td>3.</td><td>Claudia</td><td>13520076</td></tr>
<tr><td>4.</td><td>Vieri Mansyl</td><td>13520092</td></tr>
</table>

## Cara mengeksekusi program

1. Pastikan sudah menginstall GNU Prolog
2. Buka file main.pl melalui GNU Prolog. Apabila telah berada di dalam GNU Prolog, ketik 'consult('main.pl').' untuk me-run program
3. Jika sudah berhasil dicompile, masuk ke dalam permainan dengan mengetikkan 'start_game.'
4. Untuk memulai permainan, ketik 'start.'
5. Ketik 'help.' untuk mengetahui command yang bisa digunakan
6. Have fun!
